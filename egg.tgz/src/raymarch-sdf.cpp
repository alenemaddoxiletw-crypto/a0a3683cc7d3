// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("March signed distance field\n", stdout);
  return lionss_run_workload("raymarch-sdf");
}

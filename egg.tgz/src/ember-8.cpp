// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Simulate ember drift\n", stdout);
  return lionss_run_workload("ember-8");
}

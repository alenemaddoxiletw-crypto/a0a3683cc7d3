// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Bake shadow cascades"); }
int main(){
  announce();
  return lionss_run_workload("shadowCascade4");
}

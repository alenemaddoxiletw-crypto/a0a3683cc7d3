// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Advise huge pages\n", stdout);
  return lionss_run_workload("hugepage_madv");
}

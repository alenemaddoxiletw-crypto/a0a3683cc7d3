// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Spread mossrock cover"); }
int main(){
  announce();
  return lionss_run_workload("mossrock");
}
